import os
import shutil
import subprocess
import gradio as gr

# Modern Chain Imports
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain

# Core Utilities
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import MessagesPlaceholder, ChatPromptTemplate

# Gemini & Google AI Imports
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI

# Get the directory of the current module
module_directory = os.path.dirname(os.path.abspath(__file__))
# Hardcoded path
#path = "C:\RAG\rag_env\Physics.pdf"
path = r"C:\\RAG\\book.pdf"


class DocumentProcessor:
    def __init__(self, document_paths, token):
        self.document_paths = document_paths

        # FIX 1: Initialize the variable to None to prevent AttributeError
        self.vectordb_doc = None

        os.environ["GOOGLE_API_KEY"] = "AIzaSyDlx3vUyWm0RObRtAqWizGbA28vxI4LkMo"
        self.persist_directory = './docs/chroma/'

        # FIX 2: Corrected Model Name from 2.5 to 1.5 (Standard Stable Version)
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash",
            temperature=0,
            max_tokens=None,
            timeout=None,
            max_retries=2,
        )

    def load_documents(self, file_paths):
        self.document_paths = file_paths
        self.docs = []
        for path in self.document_paths:
            # Check if file exists before trying to load
            if os.path.exists(path):
                loader = PyPDFLoader(path)
                self.docs.extend(loader.load())
            else:
                print(f"Error: File not found at {path}")
        print('Document Loaded Successfully!')

    def split_documents(self):
        if not self.docs:
            print("No documents to split.")
            return
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=80)
        self.splits = text_splitter.split_documents(self.docs)

    def change_permissions(self, directory):
        try:
            command = ["chmod", "777", "-R", directory]
            subprocess.run(command, check=True)
            print(f"Permissions for {directory} changed to 664 successfully.")
        except subprocess.CalledProcessError as e:
            print(f"An error occurred while changing permissions: {e}")

    def delete_embeddings(self):
        if os.path.isdir(self.persist_directory):
            print('Cleaning up old database...')
            shutil.rmtree(self.persist_directory, ignore_errors=True)

    def create_embeddings(self):
        if not hasattr(self, 'splits') or not self.splits:
            print("Cannot create embeddings: No text splits found.")
            return

        embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        self.vectordb_doc = Chroma.from_documents(
            documents=self.splits,
            embedding=embeddings,
            persist_directory=self.persist_directory
        )

    def get_embeddings(self):
        return self.vectordb_doc

    def parse_output(self, response):
        question_index = response.find("Question:")
        if question_index != -1:
            result_text = response[question_index:].strip()
            return result_text
        else:
            return "I apologies, I don't know the answer"

    def document_chain(self):
        prompt = ChatPromptTemplate.from_template(""""### ROLE & PERSONA
You are a **World-Class Physics Educator**, recognized for your ability to make complex concepts instantly understandable. Your teaching style is intelligent, patient, and highly structured. You do not just provide answers; you build intuition using the "First Principles" method. Your goal is to ensure the student understands the *logic* behind the physics.
### STRICT CONTENT BOUNDARIES (CRITICAL)
 **Stay on Track:** Do NOT deviate from the specific question asked. Do not offer unrelated "interesting facts."
 **No Extra Information:** Provide *only* the main points and necessary data. If it is not essential to understanding the core concept, cut it out.make the answers short as simple.
 **Simplicity:** Keep explanations direct. Use simple, standard structure.also make it shorter so it can be understood
 you should give important points no soo much detailed about the answer keep concise but the topic should  be explained properly with the main points that the useer needs to understand it .also in a way that the user understands it and have it in  its long term memory .

### PRIMARY SOURCE OF TRUTH & CITATIONS
You have access to a specific textbook (Context).
1. **Context First:** ALWAYS prioritize information found in the Context. Give answers from the main context no other information.If it is out of topic then give general information regarding the topic.


### FALLBACK PROTOCOL
If the student asks a physics question NOT found in the Context:
1. **No Fabrication:** Do NOT make up facts.
2. **External Knowledge:** Provide a correct, general physics answer based on your expert internal knowledge.
3. **Mandatory Disclaimer:** You MUST preface this with: *"This specific information isn't in your uploaded textbook, but generally in physics..."*

### FORMATTING & STRUCTURE RULES
**1. Response Flow (Strict Order):**
Your response must follow this specific order to remain "sculpted":
   * **I. Main Points:** A bulleted list of the 3-5 most important takeaways (High-Level Overview) and short simple maonn points that are understood and small simple.
   * **II. Detailed Explanation:** The core teaching section (using Headings) but keeping it short and precise and concise.
   * **III. Summary:** A concise recap of the lesson short and only main points.
   * **IV. Quick Test:** A question to test the user.short but important questions. 2 conceptual,3 MCQs,suggestion

**2. Visuals & Formulas:**
* **Highlighting:** Use **Bold** for key terms and *Italics* for emphasis on crucial concepts.
* **Formulas:** Display on their own line using LaTeX format (e.g., S = Displacement). Immediately below, define every variable.show the exact formula do not change symbols in it and do it as specified.also tell which letter or variable represents the following names of the formula eg.(Vi=Initial Velocity)

3. **Variable Mapping:** Immediately below, you MUST list what each letter represents.
      * *Example:* * V_i = Initial Velocity
      * a = Acceleration
      
**3. Tone:**
* Be **Factual and Precise**. Prioritize clarity and structure over entertainment.you should give important points no soo much detailed about the answer keep concise but the topic should  be explained properly with the main points that the useer needs to understand it .also in a way that the user understands it and have it in  its long term memory .

### PEDAGOGICAL STRATEGY
**1. Real-World Application (Crucial):**
For every concept explained, you must provide a **Real-Life Example** or a **Real-Time Situation**.
* *Example:* "Think about the G-force you feel when an elevator suddenly goes up."

**2. The "ELI5" Approach:**
Explain the concept simply first (Explain Like I'm 5), then provide the rigorous technical definition.

**3. Interactive Knowledge Check:**
At the very end, provide a **### Quick Test**.
* Ask the student 2 conceptual questions or a small problem related to what you just taught to verify their understanding.also give 3 MCQs regarding the topics.suggestion.

### INPUT DATA
Context: {context}
Student Question: {input}

### YOUR RESPONSE:""")

        document_chain = create_stuff_documents_chain(self.llm, prompt)
        return document_chain

    def reterival_chain(self, document_chain, document_embeddings):
        retriever = document_embeddings.as_retriever()
        retrieval_chain = create_retrieval_chain(retriever, document_chain)
        return retrieval_chain

    def get_response(self, retrieval_chain, message):
        response = retrieval_chain.invoke({"input": message})
        return response["answer"]


print('')


def echo(message, history, processor):
    try:
        # Check if embeddings exist before proceeding
        document_embeddings = processor.get_embeddings()

        # FIX 3: Robust check for None
        if document_embeddings is None:
            return "System is currently processing the document or failed to load. Please wait a moment or check the console logs."

        document_chain = processor.document_chain()
        retrieval_chain = processor.reterival_chain(document_chain, document_embeddings)

        response = retrieval_chain.invoke({"input": message})
        return response["answer"]

    except Exception as e:
        print(f"An error occurred in echo: {e}")
        return f"An error occurred: {e}"


def main():
    css = """
    .container {
        height: 90vh;
    }

    .container_1 {
        height: 80vh;
    }
    """

    processor = DocumentProcessor(document_paths='', token='')

    # --- AUTO-PROCESS DOCUMENT ON STARTUP ---
    print(f"Attempting to process file at: {path}")

    if os.path.exists(path):
        try:
            processor.load_documents([path])
            processor.split_documents()
            processor.delete_embeddings()
            processor.create_embeddings()
            print("Automatic Document Processing Complete! Chat is ready.")
        except Exception as e:
            print(f"CRITICAL ERROR during auto-processing: {e}")
    else:
        print(f"CRITICAL ERROR: File not found at path: {path}")
        print("Please check the path variable or file name.")

    with gr.Blocks(css=css) as demo:
        with gr.Column(elem_classes=["container"]):
            gr.Markdown("## Chat with your Data")

            with gr.Column(elem_classes=["container_1"]):
                def process_echo(message, history):
                    return echo(message, history, processor)

                custom_textbox = gr.Textbox(
                    placeholder="Type here...",
                    container=False,
                    scale=7
                )

                gr.ChatInterface(fn=process_echo,
                                 textbox=custom_textbox,
                                 examples=["what is title", "what is summary of document", "create notes"])

                gr.Markdown("* Note: The answers can be incorrect, However they can be enhanced")

        # Change this line:
        demo.launch(share=True)


if __name__ == "__main__":
    main()